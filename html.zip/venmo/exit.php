<?php

header("Location: https://venmo.com/legal/us-user-agreement/");

?>
